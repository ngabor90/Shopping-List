<?php echo e($slot); ?>

<?php /**PATH C:\Users\Gábor\Desktop\Projektek\React\shopping-list\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>