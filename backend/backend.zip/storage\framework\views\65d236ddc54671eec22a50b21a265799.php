<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Gábor\Desktop\Projektek\React\shopping-list\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>